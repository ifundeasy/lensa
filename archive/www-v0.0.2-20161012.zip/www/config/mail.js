module.exports = {
    system : {
        //user : "system.lensa@gmail.com",
        user : "lensa.reporting@gmail.com",
        pass : "5pasienter"
    },
    support : {
        //user : "support.lensa@gmail.com",
        user : "lensa.reporting@gmail.com",
        pass : "5pasienter"
    },
    fake : {
        //user : "fake.lensa@gmail.com",
        user : "lensa.reporting@gmail.com",
        pass : "5pasienter"
    }
}