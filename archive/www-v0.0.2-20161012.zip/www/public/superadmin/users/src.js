$(document).ready(function(){
	$('#list-moderator-table').DataTable();
	$('#list-pelaksana-table').DataTable();
	$('#list-administrator-table').DataTable();
});