define( function() {
	"use strict";

	return ( /\S+/g );
} );
