module.exports = {
    'twitter' : {
        'clientID' : 'enter client id here',
        'clientSecret' : 'enter client secret here',
        'callbackURL' : 'enter callback here'
    }
};