module.exports = {
    connection : {
        username : "ourmongo", //delete this line if your mongo haven't required username
        password : "5pasienter", //delete this line if your mongo haven't required password
        host : "ds147905.mlab.com",
        port : 47905
    },
    database : {
        name : "eok",
        username : "admin", //delete this line if your database haven't required username
        password : "admin"  //delete this line if your database haven't required password
    }
};